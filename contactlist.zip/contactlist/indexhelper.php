<?php
	$sid=$_GET['sid'];
	$con = mysqli_connect("localhost", "root", "", "contact");
	$sql="SELECT *FROM mobilenumber  WHERE name='$sid'";
	$sql1="SELECT *FROM emailaddress  WHERE name='$sid'";
	$run=mysqli_query($con,$sql);
	$run1=mysqli_query($con,$sql1);
?>

 <html>
 <head>
 	<title></title>
 	<link rel="stylesheet" href="logo.css" type="text/css">
 	<link rel="stylesheet" type="text/css" href="style.css">
	<link rel="stylesheet" type="text/css" href="homecss.css">
 </head>
 <body>
     <div class="sign" style="margin-top:9vh">
             <span class="fast-flicker">RM-PHONE</span><span class="flicker">BOOK</span>
       </div>
 	<div class="insert">
 		<table align=center width="80%" border="1" style="margin-top:5vh;">
		<tr style="background-color:black;color:white">
			<th>Name</th>
			<th>Mobile num</th>
			<th>Email</th>
			<th>Remove</th>
		</tr>
 		<form method="post" action="deleteform.php" enctype="multipart/form-data">
			<tr>
				<td><input type="text" value="<?php echo $sid;?>" name="sid" readonly></td>
				<td>
				<?php
					while($data=mysqli_fetch_assoc($run))
					{
					?>
					<input type="checkbox" name="num[]" value="<?php echo $data['sno'];?>" checked >
					<?php echo $data['mobile'];?>
					   </br>
						<?php  
					}
				?>
				</td>
				<td>
				<?php
					while($data1=mysqli_fetch_assoc($run1))
					{
					?>
							<input type="checkbox" name="num1[]" value="<?php echo $data1['sno'];?>" checked >
							<?php echo $data1['email'];?>
							</br>
						<?php  
					}
				?>
				</td>
				<td>
					<input type="submit" name="submit1" value="delete selected">
				</td>
			</tr>	
		</table>	
	</form>
 	</div>
 	<section>
		<a href="index.php">	<input type="submit" name="submit" value="View Contacts" class="button shivam"></a>
	</section>
 </body>
 </html>
 <?php 
 /*	$con = mysqli_connect("localhost", "root", "", "contact");
 	$box=$_POST['num'];
		while(list($key,$val)=@each($box))
		{
			mysqli_query($con,"delete from mobilenumber where sno=$val");
		}
*/
  ?>