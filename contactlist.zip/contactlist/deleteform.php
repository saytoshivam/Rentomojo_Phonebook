<?php 
		$con = mysqli_connect("localhost", "root", "", "contact");
		$id=$_POST['sid'];
		$box=$_POST['num'];
		$box1=$_POST['num1'];
		while(list($key,$val)=@each($box))
		{
			mysqli_query($con,"delete from mobilenumber where sno=$val");
		}
		while(list($key,$val)=@each($box1))
		{
			mysqli_query($con,"delete from emailaddress where sno=$val");
		}
		$qry="DELETE FROM 'contactinfo' WHERE name=$id";
		$run=mysqli_query($con,$qry);
		if($run==true)
		{
			?>
			<script>
				alert('Data Deleted Successfully');
				window.open('indexhelper.php','_self');
			</script>
			<?php
		}
		else
		{
			?>
			<script>
				alert('contact and gmail has been deleted and name is saved for future preferences');
				window.open('indexhelper.php','_self');
			</script>
			<?php
		}
		mysqli_close($con);
 ?>