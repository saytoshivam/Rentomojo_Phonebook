<?php 
	$con = mysqli_connect("localhost", "root", "", "contact");
		$name=$_POST['name'];
		$mobile=$_POST['mobile'];
		
		$qry="UPDATE mobilenumber SET name='$name',mobile='$mobile' WHERE name=$name";
		$run=mysqli_query($con,$qry);
		if($run==true)
		{
			?>
			<script>
				alert('Data Updated Successfully');
				window.open('index.php','_self');
			</script>
			<?php
		}
 ?>